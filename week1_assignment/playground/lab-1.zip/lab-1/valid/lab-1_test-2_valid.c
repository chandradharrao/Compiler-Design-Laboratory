// This file contains valid C code

#include <stdio.h>

int main()
{
	int a, b;
	a = 10;
	b = 11;
	a = 131 + 4436 - 2045 * 5360 / 8997;
	if(a > b)
		if(a < b)
			if(a == b)
			{
				int a_5;
				a_5 = 7876 * 1661 + 146;
			}
	if(a <= b)
	{
		int a_4;
		a_4 = 4649 / 4116 - 1224 * 7815;
	}
	else if(a > b)
	{
		int a_3;
		a_3 = 3916 + 3698 - 3684;
	}
	else
	{
		int a_6;
		a_6 = 5067 * 3179 / 3287;
	}
	while(a < b)
		a = 10;
	while(a <= b)
	{
		while(a <= b)
		{
			while(a >= b)
			{
				int a_3;
				a_3 = 2665 + 297;
				int a_4;
				a_4 = 6423 + 3661 * 1998;
			}
		}
	}
}