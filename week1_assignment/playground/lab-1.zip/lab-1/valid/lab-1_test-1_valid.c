/*
This file contains valid C code
*/

#include <stdio.h>

int main()
{
	int a, b;
	float d, e;

	int a_1;
	a_1 = 1 + 2 - 3 / 4 * 5 + (a < (b * 2));
	float a_2;
	a_2 = (d < (e * (2.0 + 5 / 7 * 6)));
	char a_3;
	a_3 = 'a';
	double a_4;
	a_4 = 1.1 + 2.2 - 3.3 / 4.4 * 5.5;
	char a_5;
	if(a < b)
		a = 10;
	if(a >= b)
	{
		a = 131 * 4436 / 2045 + 5360;
	}
	if(a > b)
	{
		if(a < b)
		{
			if(a == b)
			{
				int a_5;
				a_5 = 7876 * 1661 + 146;
			}
		}
	}
	while(a > b)
		while(a <= b)
			while(a >= b)
			{
				int a_3;
				a_3 = 3323 == 2665 + 297 > 5816;
				int a_4;
				a_4 = 6423 + 3661 + 1998 * 9083;
			}
}